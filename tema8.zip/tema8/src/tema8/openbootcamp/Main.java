package tema8.openbootcamp;

public class Main {

    public static void main(String[] args) {

        //creo el objeto
        Persona persona = new Persona("Mónica","699548330",33);
        System.out.println("Mi nombre es " +
                persona.getNombre() + ", tengo " +
                persona.getEdad() + " años y mi teléfono de contacto es: " +
                persona.getTelefono());
    }
}


class Persona {
    private String nombre;
    private String telefono;

    private int edad;

    public Persona(String nombre, String telefono, int edad) {
        //constructor de la clase persona
        this.nombre = nombre;
        this.telefono = telefono;
        this.edad = edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getEdad() {
        return this.edad;
    }
}