#!/bin/bash

mkdir -p ~/Descargas/downloads/coches.net
cd ~/Descargas/downloads/coches.net
touch Lamborghini.txt
echo "Aventador - Huracan - Urus" >> Lamborghini.txt
cat Lamborghini.txt
touch Ferrari.txt
echo "Portofino - 812Competizione" >> Ferrari.txt
cat Ferrari.txt
cd ~/Documentos
mkdir bak
cd bak
mkdir car 
mkdir conf
cp ~/Descargas/downloads/coches.net/Lamborghini.txt ~/Documentos/bak/car
cp -r /etc/*.conf ~/Documentos/bak/conf
cp -r /etc/?ost* ~/Documentos/bak
cd ~/Descargas/downloads/coches.net
mv Ferrari.txt ~/Documentos/bak/car
cd ~/Documentos/bak/car
cat Lamborghini.txt Ferrari.txt > deportivositalianos.txt
cd ~/Documentos
zip 20220615-copiaseguridad.zip bak
mv 20220615-copiaseguridad.zip 20220615-bakSecurityCopy
rm -r ~/Descargas/downloads/coches.net
cd ~/Descargas
rmdir downloads