#!/bin/bash

resto=0
suma=0
i=0

while [ $i -le 200 ]
do
    resto=$(( i % 2 ))
    if [ $resto -ne 0 ]
    then
        suma=$(( suma + i ))
    fi
    ((i++))
done

echo "La suma de esta secuencia es de $suma."