#!/bin/bash

resto=0
suma=0
i=0

while [ $i -le 100 ]
do
    resto=$(( i % 5 ))
    if [ $resto -eq 0 ]
    then
        suma=$(( suma + i ))
    fi
    ((i++))
done

echo "La suma de esa secuencia es de $suma."