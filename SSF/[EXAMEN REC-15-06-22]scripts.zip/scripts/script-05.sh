#!/bin/bash

#crontab

30 16 * * 5 root  script-04.sh

55 23 * * 0 root  script-04.sh

15 22 * * * root  script-04.sh

55 23 1 * 5 root  script-04.sh