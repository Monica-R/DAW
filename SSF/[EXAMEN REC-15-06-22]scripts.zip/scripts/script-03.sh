#!/bin/bash

read -p "Escribe un número: " num

resto=0
suma=0
i=0

if [ $num -le 100 ]
then

    echo "Debe ser un número mayor que 100."

else

    while [ $i -le $num ]
    do
        resto=$(( i % 2 ))
        if [ $resto -eq 0 ]
        then
            suma=$(( suma + i ))
        fi
        ((i++))
    done

    echo "La suma de esa secuencia es de $suma."

fi