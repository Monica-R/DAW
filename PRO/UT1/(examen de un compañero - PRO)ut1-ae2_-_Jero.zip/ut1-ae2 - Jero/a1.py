def valid_passwd(passwd):
    warning = [
        "- Su longitud es menos de 10 caracteres", 
        "- No contiene caracteres especiales", 
        "- No contiene caracteres en mayúscula"]

    result = []

    for i in passwd:
        special = False
        if i in "*#+-.,()[]\{\}":
            special = True
            break

    if len(passwd) < 10:
        result.append(warning[0])
    if passwd == passwd.lower():
        result.append(warning[2])
    if special == False:
        result.append(warning[1])

    if len(result) == 0:
        valid = "es válida"
    else:
        valid = "no es válida porque:\n"

    return "La contraseña {} {}{}".format(passwd, valid, '\n'.join(result))
    
    
passwd1 = "As5rtG"
valid_passwd(passwd1)
passwd2 = "lej50*paRapa"
valid_passwd(passwd2)
passwd3 = "lej50paapa"
valid_passwd(passwd3)

print(valid_passwd(passwd1))
print()
print(valid_passwd(passwd2))
print()
print(valid_passwd(passwd3))