def obtener_precio(catalogo, producto):
    for prod in catalogo:
        if prod[0] == producto:
            return prod[1]

def total_compra(catalogo, carrito):
    total = 0
    for buy in carrito:
        for prod in catalogo:
            if buy[0] == prod[0]:
                total += buy[1] * prod[1]

    return total
    
def  mostrar_compra(catalogo, carrito):
    html = '''
    <table>
        <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>P U</th>
            <th>P Total</th>
        </tr>
    '''

    for buy in carrito:
        for prod in catalogo:
            if buy[0] == prod[0]:
                html += '''
        <tr>
            <td>{}</td>
            <td>{}</td>
            <td>{:.2f}€</td>
            <td>{:.2f}€</td>
        </tr>
                '''.format(buy[0], buy[1], prod[1], (buy[1] * prod[1]))

    html += '''
        <tr>
            <td colspan='4'>Total: {:.2f}€</td>
        </tr>
    </table>
    '''.format(total_compra(catalogo, carrito))

    return html


# Programa principal

catalogo = [["camiseta roja", 10.50], ["camiseta azul", 10.99], ["camiseta blanca", 9.90], ["pantalon vaquero", 21.50], ["pantalon corto", 13.50], ["chaleco", 17.20]]
carrito = [["camiseta roja", 1],["pantalon corto", 2], ["chaleco", 3]]

p_chaleco = obtener_precio(catalogo, "chaleco")
print(f"El precio del chaleco es de {p_chaleco}€.\n")

total = total_compra(catalogo, carrito)
print(f"El total de la compra es de: {total}€.\n")
            
print("El extracto de la compra en formato HTML es:\n")

print(mostrar_compra(catalogo, carrito))