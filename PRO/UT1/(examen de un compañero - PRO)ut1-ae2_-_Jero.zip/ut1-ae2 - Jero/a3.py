from random import randint

def puntuacion(a, b, c):
    result = [a, b, c]
    repeated = []
    for i in result:
        if result.count(i) > 1:
            repeated.append(i)

    if len(repeated) == 2:
        return 2
    elif len(repeated) == 3:
        return 5
    else:
        return 0


def partida(m, n):
    if m > 0:
        for i in range(n):
            if m > 0:
                m -= 1

                bet = []
                for j in range(3):
                    bet.append(randint(1, 5))

                m += puntuacion(bet[0], bet[1], bet[2])
                print(f"Tirada {j+1}: {bet} -> {m} monedas(s)")

    return m
    
    
# Programa principal
monedas = int(input("Con cuantas monedas quieres empezar: "))
n_tiradas = int(input("Cuantas tiradas quieres realizar: "))
p_final = partida(monedas, n_tiradas)
print(f"Has finalizado con {p_final} monedas")
