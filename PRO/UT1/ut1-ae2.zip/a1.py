def valid_passwd(passwd):
    # Completar código de la función
    pass # eliminar esta línea
    
passwd1 = "As5rtG"
valid_passwd(passwd1)
passwd2 = "lej50*paRapa"
valid_passwd(passwd2)
passwd3 = "lej50paapa"
valid_passwd(passwd2)