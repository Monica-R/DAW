def puntuacion(a, b, c):
    # Completar el código de esta función
    pass # Eliminar esta línea
def partida(m, n):
    # Completar el código de esta función
    pass # Eliminar esta línea
    
    
# Programa principal
monedas = int(input("Con cuantas monedas quieres empezar: "))
n_tiradas = int(input("Cuantas tiradas quieres realizar: "))
p_final = partida(monedas, n_tiradas)
print(f"Has finalizado con {p_final} monedas")