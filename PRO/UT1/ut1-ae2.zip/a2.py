def count_phrases(text):
    """
    Función a la que se le pasa un texto y devuelve el número de frases que contiene
    El caracter delimitador de frases es el punto '.'
    """
    # Completar código
    pass # Eliminar esta línea
    
def phrases_in_text(text):
    """
    Función a la que se le pasa un texto y devuelve una lista con las frases que contiene
    El caracter delimitador de frases es el punto '.'
    """
    # Completar código
    pass # Eliminar esta línea
    
 
def ordered_words(text):
    """
    Función a la que le pasamos un texto y devuelve una lista con las palabras que contiene
    La lista debe estar ordenada alfabéticamente
    Todas las palabras deben estar en minúscula
    """
    # Completar código
    pass # Eliminar esta línea
    
def n_words_end_in(letter, text):
    """
    Función a la que se le pasa una letra y un texto y devuelve el número
    de palabras de la lista que terminan por dicho carácter
    """
    # Completar código
    pass # Eliminar esta línea

def delete_word(text, word):
    """
    función a la que le pasamos un texto y una palabra y devuelve el mismo texto
    sin que aparezca la palabra a eliminar
    """
    # Completar código
    pass # Eliminar esta línea
    
paragraph = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vitae posuere nunc. Pellentesque varius metus id risus dictum tempor. Duis ac dui ac mauris commodo aliquet. Mauris vitae nisl non massa; fringilla ullamcorper quis nec libero. Interdum et malesuada fames; ac ante ipsum primis in faucibus. Duis fermentum erat eget ipsum cursus, in ullamcorper libero mattis. Nulla ac feugiat nulla, non molestie lacus. Sed sit amet elementum lectus. Integer id dui efficitur, mattis velit a, efficitur ligula. Nullam mattis enim nulla, eu molestie sem eleifend sit amet. Mauris commodo posuere pretium. Pellentesque justo metus, auctor ornare sem nec, ornare pharetra elit. "

num_phrases = count_phrases(paragraph)
print(f"El texto tiene {num_phrases} frases\n")

list_phrases = phrases_in_text(paragraph)
print(f"Las frases del texto son:\n{list_phrases}\n")

last_phrase = list_phrases[-1]
l_words_ordered = ordered_words(last_phrase)
print("La palabras de la ultima frase en orden alfabético son:\n{l_words_ordered}\n")

letter = "r"
n_words_end = n_words_end_in(letter, last_phrase)
print("En la última frase hay {n_words_end} palabra(s) que terminan en {letter}:\n{l_words_ordered}\n")

phrase4 = list_phrases[3]
text_without_word = delete_word(phrase4, "ac")
print("La cuarta frase sin la palabra 'ac' queda:\n{text_without_word}\n")